# BadVpnGuard
Android (Kotlin + Jetpack Compose) 악성 VPN 탐지 & 메타데이터 기반 개인정보 유출 보조.

## Build
- Open in Android Studio (JDK 17)
- Put API keys (VirusTotal/Shodan) into `BuildConfig` or gradle.properties
- Run

## Features
- VPN 감지 / DNS 누수 휴리스틱
- VirusTotal/Shodan 평판 조회 (캐시)
- 위험도 스코어링 & 알림
- (옵션) Local VpnService 가드 모드 스켈레톤 (콘텐츠 미수집)
