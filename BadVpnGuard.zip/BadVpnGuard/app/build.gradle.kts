plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
  id("org.jetbrains.kotlin.kapt")
}
android {
  namespace = "com.example.badvpnguard"
  compileSdk = 34
  defaultConfig {
    applicationId = "com.example.badvpnguard"
    minSdk = 26
    targetSdk = 34
    versionCode = 1
    versionName = "1.0"
    buildConfigField("String", "VT_API_KEY", """")
    buildConfigField("String", "SHODAN_API_KEY", """")
  }
  buildTypes {
    debug { isMinifyEnabled = false }
    release {
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
    }
  }
  buildFeatures { compose = true }
  composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
  packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}
dependencies {
  implementation("androidx.core:core-ktx:1.13.1")
  implementation("androidx.activity:activity-compose:1.9.2")
  implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
  implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
  implementation("androidx.compose.ui:ui:1.6.8")
  implementation("androidx.compose.ui:ui-tooling-preview:1.6.8")
  implementation("androidx.compose.material3:material3:1.2.1")
  debugImplementation("androidx.compose.ui:ui-tooling:1.6.8")
  implementation("androidx.navigation:navigation-compose:2.8.0")
  implementation("androidx.work:work-runtime-ktx:2.9.1")
  implementation("androidx.room:room-runtime:2.6.1")
  kapt("androidx.room:room-compiler:2.6.1")
  implementation("androidx.room:room-ktx:2.6.1")
  implementation("com.squareup.retrofit2:retrofit:2.11.0")
  implementation("com.squareup.retrofit2:converter-moshi:2.11.0")
  implementation("com.squareup.okhttp3:okhttp:4.12.0")
  implementation("com.squareup.moshi:moshi-kotlin:1.15.1")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
  implementation("androidx.core:core-splashscreen:1.0.1")
}
