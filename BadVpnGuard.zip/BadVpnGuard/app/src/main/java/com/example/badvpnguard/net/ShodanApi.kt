package com.example.badvpnguard.net

import com.squareup.moshi.Json
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

data class ShodanHost(
  @Json(name="ip_str") val ip: String?,
  @Json(name="ports") val ports: List<Int>?,
  @Json(name="hostnames") val hostnames: List<String>?,
  @Json(name="org") val org: String?,
  @Json(name="isp") val isp: String?
)

interface ShodanApi {
  @GET("shodan/host/{ip}")
  suspend fun getHost(@Path("ip") ip: String, @Query("key") key: String): ShodanHost
}
