package com.example.badvpnguard.net

import com.squareup.moshi.Json
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path

data class VtIpData(@Json(name="data") val data: VtIpCore?)
data class VtIpCore(@Json(name="attributes") val attributes: VtIpAttributes?)
data class VtIpAttributes(@Json(name="last_analysis_stats") val stats: VtStats?)
data class VtStats(val harmless: Int? = 0, val malicious: Int? = 0, val suspicious: Int? = 0, val undetected: Int? = 0, val timeout: Int? = 0)

interface VirusTotalApi {
  @GET("v3/ip_addresses/{ip}")
  suspend fun getIpReport(@Header("x-apikey") apiKey: String, @Path("ip") ip: String): VtIpData
}
