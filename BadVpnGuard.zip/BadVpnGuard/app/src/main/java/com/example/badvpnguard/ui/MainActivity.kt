package com.example.badvpnguard.ui

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    if (Build.VERSION.SDK_INT >= 33) {
      val req = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
      req.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    setContent {
      MaterialTheme {
        val vm: VpnViewModel = viewModel(factory = VpnViewModel.factory(application))
        Scaffold(topBar = { SmallTopAppBar(title = { Text("BadVpnGuard") }) }) { pad ->
          HomeScreen(modifier = androidx.compose.ui.Modifier.padding(pad), vm = vm)
        }
      }
    }
  }
}
