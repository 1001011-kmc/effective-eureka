package com.example.badvpnguard.ui

import android.net.VpnService
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(modifier: Modifier = Modifier, vm: VpnViewModel) {
  val ui by vm.ui.collectAsState()
  var guardOn by remember { mutableStateOf(false) }

  Column(modifier.padding(16.dp)) {
    Text(if (ui.isVpn) "VPN 연결 감지됨" else "VPN 미사용")
    Spacer(Modifier.height(8.dp))
    Text("Exit IP: ${ui.ip ?: "알 수 없음"}")
    Text("DNS: ${if (ui.dnsServers.isEmpty()) "없음" else ui.dnsServers.joinToString()}")
    Spacer(Modifier.height(8.dp))
    Text("위험도: ${ui.level} (score=${ui.score})")
    ui.reasons.forEach { Text("• $it") }

    Spacer(Modifier.height(16.dp))
    Button(onClick = {
      guardOn = !guardOn
      if (guardOn) {
        val prep = VpnService.prepare(vm.app)
        if (prep != null) vm.launchVpnPermission(prep) else vm.startLocalGuard()
      } else vm.stopLocalGuard()
    }) { Text(if (guardOn) "가드 모드 끄기" else "가드 모드 켜기") }
  }
}
