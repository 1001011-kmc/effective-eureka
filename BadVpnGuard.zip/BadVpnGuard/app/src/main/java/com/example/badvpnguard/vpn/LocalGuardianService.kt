package com.example.badvpnguard.vpn

import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import com.example.badvpnguard.ui.Notifier

class LocalGuardianService : VpnService() {
  private var vpnInterface: ParcelFileDescriptor? = null
  override fun onCreate() {
    super.onCreate(); Notifier.ensureChannel(this)
    startForeground(1001, Notifier.buildPersistent(this))
  }
  override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
    setupTunnel(); return START_STICKY
  }
  private fun setupTunnel() {
    val builder = Builder().setSession("BadVpnGuard Local VPN")
      .addAddress("10.0.0.2", 32).addDnsServer("1.1.1.1")
      .allowFamily(OsConstants.AF_INET).allowFamily(OsConstants.AF_INET6)
      .addDisallowedApplication(packageName)
    vpnInterface?.close(); vpnInterface = builder.establish()
  }
  override fun onDestroy() { vpnInterface?.close(); super.onDestroy() }
}
