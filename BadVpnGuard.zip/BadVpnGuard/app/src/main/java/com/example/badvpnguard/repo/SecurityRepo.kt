package com.example.badvpnguard.repo

import android.content.Context
import androidx.room.Room
import com.example.badvpnguard.BuildConfig
import com.example.badvpnguard.data.AppDb
import com.example.badvpnguard.data.IpReputationCache
import com.example.badvpnguard.net.Apis
import com.example.badvpnguard.risk.RiskInputs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SecurityRepo(ctx: Context) {
  private val db = Room.databaseBuilder(ctx, AppDb::class.java, "rep.db").build()
  private val dao = db.repDao()

  suspend fun getIpRisk(ip: String): RiskInputs = withContext(Dispatchers.IO) {
    val cached = dao.get(ip); val now = System.currentTimeMillis()
    if (cached != null && now - cached.updatedAt < 6 * 60 * 60 * 1000L) {
      return@withContext RiskInputs(
        vtMalicious = cached.vtMalicious,
        vtSuspicious = cached.vtSuspicious,
        shodanOpenPorts = cached.portsCsv.split(',').filter { it.isNotBlank() }.map { it.toInt() }
      )
    }
    val vt = runCatching { Apis.vt.getIpReport(BuildConfig.VT_API_KEY, ip) }.getOrNull()
    val mal = vt?.data?.attributes?.stats?.malicious ?: 0
    val sus = vt?.data?.attributes?.stats?.suspicious ?: 0
    val shodan = runCatching { Apis.shodan.getHost(ip, BuildConfig.SHODAN_API_KEY) }.getOrNull()
    val ports = shodan?.ports ?: emptyList()
    dao.put(IpReputationCache(ip, mal, sus, ports.joinToString(","), now))
    return@withContext RiskInputs(vtMalicious = mal, vtSuspicious = sus, shodanOpenPorts = ports)
  }
}
