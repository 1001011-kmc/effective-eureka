package com.example.badvpnguard.risk

data class RiskInputs(
  val vtMalicious: Int = 0,
  val vtSuspicious: Int = 0,
  val shodanOpenPorts: List<Int> = emptyList(),
  val dnsLeak: Boolean = false,
  val appOverPermission: Boolean = false,
  val iocHit: Boolean = false,
  val wsSuspicious: Boolean = false,
  val uploadSpike: Boolean = false,
  val dnsLeakStrong: Boolean = false
)
enum class RiskLevel { SAFE, WARN, DANGER }
data class RiskResult(val score: Int, val level: RiskLevel, val reasons: List<String>)

object RiskScorer {
  fun score(i: RiskInputs): RiskResult {
    var s = 0; val reasons = mutableListOf<String>()
    if (i.vtMalicious > 0) { s += i.vtMalicious * 15; reasons += "VirusTotal: 악성 ${i.vtMalicious}" }
    if (i.vtSuspicious > 0) { s += i.vtSuspicious * 8; reasons += "VirusTotal: 의심 ${i.vtSuspicious}" }
    val weirdPorts = i.shodanOpenPorts.filter { it !in listOf(1194,443,80,51820,1701,500,4500,1723) }
    if (weirdPorts.isNotEmpty()) { s += 10; reasons += "Shodan: 비정상 포트 ${weirdPorts.take(5)}" }
    if (i.dnsLeak) { s += 25; reasons += "DNS 누수 의심" }
    if (i.appOverPermission) { s += 10; reasons += "앱 과도 권한" }
    if (i.iocHit) { s += 40; reasons += "IOC 매칭(C2/프록시)" }
    if (i.wsSuspicious) { s += 15; reasons += "WebSocket 의심" }
    if (i.uploadSpike) { s += 20; reasons += "이상 업로드 스파이크" }
    if (i.dnsLeakStrong) { s += 25; reasons += "강한 DNS 누수 정황" }
    val level = when { s >= 60 -> RiskLevel.DANGER; s >= 30 -> RiskLevel.WARN; else -> RiskLevel.SAFE }
    return RiskResult(s, level, reasons)
  }
}
