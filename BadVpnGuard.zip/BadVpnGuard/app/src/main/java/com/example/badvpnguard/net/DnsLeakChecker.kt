package com.example.badvpnguard.net

import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object DnsLeakChecker {
  data class Result(val dnsServers: List<String>, val suspectedLeak: Boolean, val note: String)
  fun extractDnsServers(lp: LinkProperties?): List<String> = lp?.dnsServers?.map { it.hostAddress } ?: emptyList()

  suspend fun checkLeakHeuristic(cm: ConnectivityManager, network: Network, dnsServers: List<String>): Result =
    withContext(Dispatchers.IO) {
      val myIp = runCatching {
        cm.bindProcessToNetwork(network)
        val url = URL("https://api.ipify.org?format=text")
        (url.openConnection() as HttpURLConnection).run {
          connectTimeout = 3000; readTimeout = 3000
          inputStream.bufferedReader().use { it.readText() }
        }
      }.getOrDefault("unknown")
      val suspected = dnsServers.any { ip ->
        ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.16.") ||
        ip.startsWith("127.") || ip == "0.0.0.0"
      }
      Result(dnsServers, suspected, "publicIP=$myIp")
    }
}
