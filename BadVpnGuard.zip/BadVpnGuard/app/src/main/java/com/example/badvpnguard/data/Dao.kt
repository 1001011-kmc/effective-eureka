package com.example.badvpnguard.data

import androidx.room.*

@Dao
interface RepDao {
  @Query("SELECT * FROM IpReputationCache WHERE ip=:ip")
  suspend fun get(ip: String): IpReputationCache?
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun put(e: IpReputationCache)
}
