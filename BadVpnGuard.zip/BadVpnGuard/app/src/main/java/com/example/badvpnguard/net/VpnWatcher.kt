package com.example.badvpnguard.net

import android.content.Context
import android.net.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow

data class VpnSessionState(
  val isVpnActive: Boolean,
  val activeNetwork: Network?,
  val linkProperties: LinkProperties?,
  val capabilities: NetworkCapabilities?
)

class VpnWatcher(context: Context) {
  private val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
  fun observeVpn() = callbackFlow {
    val cb = object : ConnectivityManager.NetworkCallback() {
      override fun onAvailable(network: Network) = emit()
      override fun onLost(network: Network) = emit()
      override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = emit()
      override fun onLinkPropertiesChanged(network: Network, props: LinkProperties) = emit()
      fun emit() {
        val n = cm.activeNetwork
        val caps = n?.let { cm.getNetworkCapabilities(it) }
        val lp = n?.let { cm.getLinkProperties(it) }
        val isVpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        trySend(VpnSessionState(isVpn, n, lp, caps))
      }
    }
    cm.registerDefaultNetworkCallback(cb)
    awaitClose { cm.unregisterNetworkCallback(cb) }
  }
}
