package com.example.badvpnguard.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class IpReputationCache(
  @PrimaryKey val ip: String,
  val vtMalicious: Int,
  val vtSuspicious: Int,
  val portsCsv: String,
  val updatedAt: Long
)
