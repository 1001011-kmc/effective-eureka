package com.example.badvpnguard.net

import com.squareup.moshi.Moshi
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object Apis {
  private val moshi = Moshi.Builder().build()
  val vt: VirusTotalApi by lazy {
    Retrofit.Builder().baseUrl("https://www.virustotal.com/api/")
      .addConverterFactory(MoshiConverterFactory.create(moshi)).build().create(VirusTotalApi::class.java)
  }
  val shodan: ShodanApi by lazy {
    Retrofit.Builder().baseUrl("https://api.shodan.io/")
      .addConverterFactory(MoshiConverterFactory.create(moshi)).build().create(ShodanApi::class.java)
  }
}
