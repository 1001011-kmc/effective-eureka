package com.example.badvpnguard.ui

import android.app.Application
import android.content.Intent
import android.net.ConnectivityManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.badvpnguard.net.DnsLeakChecker
import com.example.badvpnguard.net.VpnWatcher
import com.example.badvpnguard.repo.SecurityRepo
import com.example.badvpnguard.risk.RiskInputs
import com.example.badvpnguard.risk.RiskScorer
import com.example.badvpnguard.vpn.LocalGuardianService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UiState(
  val isVpn: Boolean = false,
  val ip: String? = null,
  val dnsServers: List<String> = emptyList(),
  val score: Int = 0,
  val level: String = "SAFE",
  val reasons: List<String> = emptyList()
)

class VpnViewModel(val app: Application) : AndroidViewModel(app) {
  private val watcher = VpnWatcher(app)
  private val cm = app.getSystemService(ConnectivityManager::class.java)
  private val repo = SecurityRepo(app)

  private val _ui = MutableStateFlow(UiState())
  val ui = _ui.asStateFlow()

  init {
    viewModelScope.launch {
      watcher.observeVpn().collect { state ->
        if (!state.isVpnActive) { _ui.value = UiState(isVpn = false); return@collect }
        val dns = DnsLeakChecker.extractDnsServers(state.linkProperties)
        val leak = DnsLeakChecker.checkLeakHeuristic(cm, state.activeNetwork!!, dns)
        val vpnExitIp = leak.note.removePrefix("publicIP=").takeIf { it.isNotBlank() && it != "unknown" }
        val base = if (vpnExitIp != null) repo.getIpRisk(vpnExitIp) else RiskInputs()
        val final = RiskScorer.score(base.copy(dnsLeak = leak.suspectedLeak))
        _ui.value = UiState(true, vpnExitIp, dns, final.score, final.level.name, final.reasons)
      }
    }
  }

  fun launchVpnPermission(prepIntent: Intent) {
    prepIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    app.startActivity(prepIntent)
  }
  fun startLocalGuard() = app.startService(Intent(app, LocalGuardianService::class.java))
  fun stopLocalGuard() = app.stopService(Intent(app, LocalGuardianService::class.java))

  companion object {
    fun factory(app: Application) = object : ViewModelProvider.AndroidViewModelFactory(app) {
      override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T = VpnViewModel(app) as T
    }
  }
}
